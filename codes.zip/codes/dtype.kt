//display range of int datatype
fun main(){
  val a = Int.MIN_VALUE
  val b = Int.MAX_VALUE
  println("$a to $b")
}