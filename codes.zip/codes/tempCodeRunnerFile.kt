import java.time.Duration
import java.time.LocalTime
import java.time.format.DateTimeFormatter
class TimePeriod(val startTime: LocalTime, val endTime: LocalTime) {
    fun calculateDuration(): Duration {
        return Duration.between(startTime, endTime)
    }
    fun printDuration() {
        val duration = calculateDuration()
        val hours = duration.toHours()
        val minutes = duration.toMinutes() % 60
        val seconds = duration.seconds % 60
        println("Duration: $hours hours, $minutes minutes, $seconds seconds")
    }
}
fun main() {
    val startTimeString = "09:30:00"
    val endTimeString = "12:45:30"

    val formatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    val startTime = LocalTime.parse(startTimeString, formatter)
    val endTime = LocalTime.parse(endTimeString, formatter)

    val timePeriod = TimePeriod(startTime, endTime)
    timePeriod.printDuration()
}
